// std::deque demo
// by Eduardo Corpe�o

#include <iostream>
#include <deque>

using namespace std;

int main(){
	return 0;
}



