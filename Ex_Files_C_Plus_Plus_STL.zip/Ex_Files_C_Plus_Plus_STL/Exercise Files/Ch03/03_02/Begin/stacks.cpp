// std::stack demo
// by Eduardo Corpe�o

#include <iostream>
#include <stack>

using namespace std;

int main(){
	return 0;
}



