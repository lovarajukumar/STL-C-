// std::vector demo
// by Eduardo Corpe�o

#include <iostream>
#include <vector>

using namespace std;

void print(const vector<int>& my_vector){
	cout<<"Vector content: {  ";
		
	cout<<"}\n\n";	
}

int main(){
	
	return 0;
}

