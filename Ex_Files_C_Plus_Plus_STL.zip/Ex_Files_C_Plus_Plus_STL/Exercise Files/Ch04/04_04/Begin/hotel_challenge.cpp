// Hotel Application
// map usage challenge
// by Eduardo Corpe�o

#include <iostream>
#include <map>
#include <unordered_map>

using namespace std;

int main(){
	map<int,string> hotel;
	int temp;
	string str;
	pair<int,string> p;
	
	cout<<"Inserting...\n";
	while(temp>=0){
		cout<<"Enter room number: ";
		getline(cin,str);
		temp=stoi(str);
		if(temp>=0){
			p.first=temp;
			cout<<"Enter name: ";
			getline(cin,str);
			p.second=str;
			hotel.insert(p);
		}
	}
	
	cout<<"{   ";
	for(auto it = hotel.begin(); it!=hotel.end();it++)
		cout << it->first << "->" << it->second << "   ";
	cout<<"}\n";
	
	return 0;
}








