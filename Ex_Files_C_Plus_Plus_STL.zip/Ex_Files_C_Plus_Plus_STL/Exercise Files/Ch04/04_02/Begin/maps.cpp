// std::map and variants demo
// by Eduardo Corpe�o

#include <iostream>
#include <map>
#include <unordered_map>

using namespace std;

int main(){
	map<int,string> this_map;
	int temp;
	string str;
	
	return 0;
}









